# SPDX-License-Identifier: Apache-2.0

"""
Tests for HDR mode entry, exit, and error recovery.

Covers:
  - HDR-DDR write/read with HDR exit pattern (I3C spec 5.2.1.1.1)
  - HDR-DDR with repeated start (RSTART) and exit
  - Optional 60us HDR error recovery timer (I3C spec 1.10.1.9)
"""

import logging
import random

from boot import boot_init
from bus2csr import dword2int, int2dword
from i3c_controller_fixed import I3cControllerFixed as I3cController
from cocotbext_i3c.i3c_target import I3CTarget
from interface import I3CTopTestInterface

import cocotb
from cocotb.triggers import ClockCycles, Timer

# =============================================================================
# Constants
# =============================================================================

from common import VALID_I3C_ADDRESSES, log_seed

# CCC codes
ENTHDR0 = 0x20
GETSTATUS = 0x90

# DUT FSM state values (from i3c_target_fsm.sv primary_state_e)
FSM_STATE_IDLE = 0
FSM_STATE_IN_HDR_MODE = 19

# DUT hierarchy path to FSM state register
FSM_STATE_PATH = (
    "xi3c_wrapper.gen_target_config.i3c.xcontroller.gen_target_controller_standby.xcontroller_standby"
    ".xcontroller_standby_i3c.xi3c_target_fsm.state_q"
)

# HDR timeout test threshold (small value so tests run fast)
TEST_HDR_TIMEOUT_CYCLES = 200


# =============================================================================
# Helpers: Test setup
# =============================================================================

async def test_setup(dut, static_addr=0x5A, virtual_static_addr=0x5B,
                     dynamic_addr=None, virtual_dynamic_addr=None,
                     hdr_timeout_en=False, hdr_timeout_cycles=None,
                     attach_target=True):
    """Sets up controller, target models and top-level core interface."""

    cocotb.log.setLevel(logging.DEBUG)
    log_seed(dut)

    i3c_controller = I3cController(
        sda_i=dut.bus_sda,
        sda_o=dut.sda_sim_ctrl_i,
        scl_i=dut.bus_scl,
        scl_o=dut.scl_sim_ctrl_i,
        debug_state_o=None,
        speed=12.5e6,
    )

    if attach_target:
        i3c_target = I3CTarget(  # noqa
            sda_i=dut.bus_sda,
            sda_o=dut.sda_sim_target_i,
            scl_i=dut.bus_scl,
            scl_o=dut.scl_sim_target_i,
            debug_state_o=None,
            speed=12.5e6,
        )
    else:
        i3c_target = None
        dut.sda_sim_target_i.setimmediatevalue(1)
        dut.scl_sim_target_i.setimmediatevalue(1)

    tb = I3CTopTestInterface(dut)
    await tb.setup()
    await ClockCycles(tb.clk, 50)
    await boot_init(tb, static_addr=static_addr,
                    virtual_static_addr=virtual_static_addr,
                    dynamic_addr=dynamic_addr,
                    virtual_dynamic_addr=virtual_dynamic_addr,
                    hdr_timeout_en=hdr_timeout_en,
                    hdr_timeout_cycles=hdr_timeout_cycles)
    return i3c_controller, i3c_target, tb


def get_remaining_addrs(*exclude):
    """Return VALID_I3C_ADDRESSES with the given addresses removed."""
    addrs = VALID_I3C_ADDRESSES.copy()
    for a in exclude:
        addrs.remove(a)
    return addrs


# =============================================================================
# Helpers: FSM state
# =============================================================================

def get_fsm_state(dut):
    """Read the current FSM state_d value."""
    return int(getattr(dut, FSM_STATE_PATH).value)


def assert_fsm_idle(dut):
    assert get_fsm_state(dut) == FSM_STATE_IDLE, \
        f"Expected Idle ({FSM_STATE_IDLE}), got {get_fsm_state(dut)}"


def assert_fsm_in_hdr_mode(dut):
    assert get_fsm_state(dut) == FSM_STATE_IN_HDR_MODE, \
        f"Expected InHDRMode ({FSM_STATE_IN_HDR_MODE}), got {get_fsm_state(dut)}"


# =============================================================================
# Helpers: Bus operations and verification
# =============================================================================

async def verify_target_responsive(i3c_controller, dynamic_addr):
    """Verify the target is responsive by sending GETSTATUS CCC.

    Checks that the target ACKs the direct CCC (i.e., is not deaf).
    The status value itself may vary depending on prior error conditions.
    """
    status_data = await i3c_controller.i3c_ccc_read(
        ccc=GETSTATUS, addr=dynamic_addr, count=2, stop=True
    )
    ack = status_data[0][0]
    cocotb.log.info(f"GETSTATUS response from {hex(dynamic_addr)}: ack={ack}, "
                    f"data={status_data[0][1].hex()}")
    assert ack, f"Target at {hex(dynamic_addr)} NACKed GETSTATUS — not responsive"


async def hold_bus_high(i3c_controller, i3c_target, tb, cycles):
    """Hold both SCL and SDA high for specified number of clock cycles.

    Releases both the controller and target model bus drivers to ensure
    the open-drain bus actually goes high.
    """
    i3c_controller.scl = 1
    i3c_controller.sda = 1
    i3c_target.sda_o.value = 1
    i3c_target.scl_o.value = 1
    await ClockCycles(tb.clk, cycles)


# =============================================================================
# Helpers: TE0/TE1 error injection (delegates to I3cControllerFixed)
# =============================================================================

async def trigger_te0_error(i3c_controller):
    """Trigger a TE0 error. See I3cControllerFixed.send_te0_error()."""
    await i3c_controller.send_te0_error()


async def trigger_te1_error(i3c_controller, i3c_target):
    """Trigger a TE1 error, pausing the cocotb target model first.

    The cocotb I3CTarget model also monitors the bus and will crash on a
    parity error assertion.  We pause it before injecting the error and
    release the bus lines so the model doesn't hold SDA low.
    """
    # Pause the cocotb target model so it doesn't crash on the bad parity
    i3c_target.monitor_enable.clear()
    await i3c_target.monitor_idle.wait()
    i3c_target.sda_o.value = 1
    i3c_target.scl_o.value = 1

    await i3c_controller.send_te1_error()


# =============================================================================
# Tests: HDR-DDR entry and exit via HDR Exit Pattern
# =============================================================================

@cocotb.test()
async def test_enter_exit_hdr_mode_write(dut):
    """Single HDR-DDR write with exit pattern."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    remaining_addrs = get_remaining_addrs(
        STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    for _ in range(random.randint(10, 15)):
        await i3c_controller.i3c_ccc_write(
            ENTHDR0, broadcast_data=[], stop=False, pull_scl_low=True)
        await ClockCycles(tb.clk, 10)
        assert_fsm_in_hdr_mode(dut)

        test_addr = random.choice(remaining_addrs)
        data_len = random.randint(1, 8)
        test_data = [random.randint(0, 0xFFFF) for _ in range(data_len)]
        accept_data = random.randint(0, 1)
        i3c_target.address = test_addr if accept_data == 1 else 0

        cocotb.log.info(f"Sending HDR-DDR write to {hex(test_addr)} with data: {test_data}")
        test_data = await i3c_controller.send_hdr_ddr_write(
            addr=test_addr, data=test_data)
        assert (
            (test_data.nack == True and accept_data == 0) or
            (test_data.nack == False and accept_data == 1)
        ), f"HDR-DDR ACK/NACK mismatch: nack={test_data.nack}, accept_data={accept_data}" 

        await i3c_controller.send_hdr_exit()
        i3c_target.address = 0
        assert_fsm_idle(dut)
        await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)

    await tb.teardown()


@cocotb.test()
async def test_enter_restart_exit_hdr_mode_write(dut):
    """Multiple HDR-DDR writes with RSTART, final exit pattern."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    remaining_addrs = get_remaining_addrs(
        STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    for _ in range(random.randint(10, 15)):
        await i3c_controller.i3c_ccc_write(
            ENTHDR0, broadcast_data=[], stop=False, pull_scl_low=True)
        await ClockCycles(tb.clk, 10)
        assert_fsm_in_hdr_mode(dut)

        transactions = random.randint(10, 15)
        for i in range(transactions):
            test_addr = random.choice(remaining_addrs)
            data_len = random.randint(1, 8)
            test_data = [random.randint(0, 0xFFFF) for _ in range(data_len)]
            accept_data = random.randint(0, 1)
            i3c_target.address = test_addr if accept_data == 1 else 0

            cocotb.log.info(f"Sending HDR-DDR write to {hex(test_addr)} with data: {test_data}")
            test_data = await i3c_controller.send_hdr_ddr_write(
                addr=test_addr, data=test_data)
            assert (
                (test_data.nack == True and accept_data == 0) or
                (test_data.nack == False and accept_data == 1)
            ), f"HDR-DDR write ACK/NACK mismatch: nack={test_data.nack}, accept_data={accept_data}"

            if i != transactions - 1:
                await i3c_controller.send_hdr_rstart()
            else:
                await i3c_controller.send_hdr_exit()
            i3c_target.address = 0

        assert_fsm_idle(dut)
        await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)

    await tb.teardown()


@cocotb.test()
async def test_enter_exit_hdr_mode_read(dut):
    """Single HDR-DDR read with exit pattern."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    remaining_addrs = get_remaining_addrs(
        STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    for _ in range(random.randint(10, 15)):
        await i3c_controller.i3c_ccc_write(
            ENTHDR0, broadcast_data=[], stop=False, pull_scl_low=True)
        await ClockCycles(tb.clk, 10)
        assert_fsm_in_hdr_mode(dut)

        test_addr = random.choice(remaining_addrs)
        data_len = random.randint(1, 8)
        exp_data = [random.randint(0, 0xFFFF) for _ in range(data_len)]
        accept_data = random.randint(0, 1)
        i3c_target.address = test_addr if accept_data == 1 else 0
        i3c_target._mem.clear()
        i3c_target._mem.write(
            [byte for word in exp_data for byte in word.to_bytes(2, "big")],
            2 * data_len
        )

        cocotb.log.info(f"Sending HDR-DDR read to {hex(test_addr)} with length: {data_len}")
        test_data = await i3c_controller.send_hdr_ddr_read(addr=test_addr)
        assert (
            (test_data.nack == True and accept_data == 0) or
            (test_data.nack == False and accept_data == 1)
        ), f"HDR-DDR ACK/NACK mismatch: nack={test_data.nack}, accept_data={accept_data}" 

        await i3c_controller.send_hdr_exit()
        i3c_target.address = 0
        assert_fsm_idle(dut)
        await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)

    await tb.teardown()


@cocotb.test()
async def test_enter_restart_exit_hdr_mode_read(dut):
    """Multiple HDR-DDR reads with RSTART, final exit pattern."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    remaining_addrs = get_remaining_addrs(
        STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR)

    for _ in range(random.randint(10, 15)):
        await i3c_controller.i3c_ccc_write(
            ENTHDR0, broadcast_data=[], stop=False, pull_scl_low=True)
        await ClockCycles(tb.clk, 10)
        assert_fsm_in_hdr_mode(dut)

        transactions = random.randint(10, 15)
        for i in range(transactions):
            test_addr = random.choice(remaining_addrs)
            data_len = random.randint(1, 8)
            exp_data = [random.randint(0, 0xFFFF) for _ in range(data_len)]
            accept_data = random.randint(0, 1)
            i3c_target.address = test_addr if accept_data == 1 else 0
            i3c_target._mem.clear()
            i3c_target._mem.write(
                [byte for word in exp_data for byte in word.to_bytes(2, "big")],
                2 * data_len
            )

            cocotb.log.info(f"Sending HDR-DDR read to {hex(test_addr)} with length: {data_len}")
            test_data = await i3c_controller.send_hdr_ddr_read(addr=test_addr)
            assert (
                (test_data.nack == True and accept_data == 0) or
                (test_data.nack == False and accept_data == 1)
            ), f"HDR-DDR read ACK/NACK mismatch: nack={test_data.nack}, accept_data={accept_data}"

            if i != transactions - 1:
                await i3c_controller.send_hdr_rstart()
            else:
                await i3c_controller.send_hdr_exit()
            i3c_target.address = 0

        assert_fsm_idle(dut)
        await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)


# =============================================================================
# Tests: HDR error recovery timer (I3C spec 1.10.1.9)
# =============================================================================

    await tb.teardown()

@cocotb.test()
async def test_hdr_timeout_recovery_te0(dut):
    """60us timeout recovery after TE0 error (invalid reserved address)."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR,
        hdr_timeout_en=True, hdr_timeout_cycles=TEST_HDR_TIMEOUT_CYCLES)
    tb.te_error_monitor.expect_error(0)

    # Enable TE0 interrupt so STATUS bit is captured
    te0_en_field = tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_ENABLE.TE0_ERR_EN
    await tb.write_csr_field(
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_ENABLE.base_addr, te0_en_field, 1)
    # Clear stale status and counter
    await tb.write_csr(
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_STATUS.base_addr, int2dword(0xFFFFFFFF), 4)
    await tb.write_csr(tb.reg_map.I3C_EC.TTI.TARGET_ERR_CNT_TE0.base_addr, int2dword(0), 4)

    await trigger_te0_error(i3c_controller)
    await ClockCycles(tb.clk, 10)
    assert_fsm_in_hdr_mode(dut)

    await hold_bus_high(i3c_controller, i3c_target, tb, TEST_HDR_TIMEOUT_CYCLES + 50)
    assert_fsm_idle(dut)

    await i3c_controller.send_stop()
    i3c_controller.give_bus_control()

    # Verify TE0 error registers
    te0_cnt = dword2int(
        await tb.read_csr(tb.reg_map.I3C_EC.TTI.TARGET_ERR_CNT_TE0.base_addr, 4)) & 0xFF
    te0_stat = await tb.read_csr_field(
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_STATUS.base_addr,
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_STATUS.TE0_ERR_STAT)
    dut._log.info(f"TE0 counter={te0_cnt}, status={te0_stat}")
    assert te0_cnt >= 1, f"Expected TE0 counter >= 1, got {te0_cnt}"
    assert te0_stat == 1, f"Expected TE0_ERR_STAT=1, got {te0_stat}"

    await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)
    tb.te_error_monitor.check()

    await tb.teardown()


@cocotb.test()
async def test_hdr_timeout_recovery_te1(dut):
    """60us timeout recovery after TE1 error (CCC parity error)."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR,
        hdr_timeout_en=True, hdr_timeout_cycles=TEST_HDR_TIMEOUT_CYCLES)
    tb.te_error_monitor.expect_error(1)

    # Enable TE1 interrupt so STATUS bit is captured
    te1_en_field = tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_ENABLE.TE1_ERR_EN
    await tb.write_csr_field(
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_ENABLE.base_addr, te1_en_field, 1)
    # Clear stale status and counter
    await tb.write_csr(
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_STATUS.base_addr, int2dword(0xFFFFFFFF), 4)
    await tb.write_csr(tb.reg_map.I3C_EC.TTI.TARGET_ERR_CNT_TE1.base_addr, int2dword(0), 4)

    await trigger_te1_error(i3c_controller, i3c_target)
    await ClockCycles(tb.clk, 10)
    assert_fsm_in_hdr_mode(dut)

    await hold_bus_high(i3c_controller, i3c_target, tb, TEST_HDR_TIMEOUT_CYCLES + 50)
    assert_fsm_idle(dut)

    await i3c_controller.send_stop()
    i3c_controller.give_bus_control()

    # Re-enable the cocotb target model after recovery
    i3c_target.monitor_enable.set()

    # Verify TE1 error registers
    te1_cnt = dword2int(
        await tb.read_csr(tb.reg_map.I3C_EC.TTI.TARGET_ERR_CNT_TE1.base_addr, 4)) & 0xFF
    te1_stat = await tb.read_csr_field(
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_STATUS.base_addr,
        tb.reg_map.I3C_EC.TTI.TARGET_ERR_INTR_STATUS.TE1_ERR_STAT)
    dut._log.info(f"TE1 counter={te1_cnt}, status={te1_stat}")
    assert te1_cnt >= 1, f"Expected TE1 counter >= 1, got {te1_cnt}"
    assert te1_stat == 1, f"Expected TE1_ERR_STAT=1, got {te1_stat}"

    await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)
    tb.te_error_monitor.check()

    await tb.teardown()


@cocotb.test()
async def test_hdr_timeout_does_not_fire_for_ccc_hdr(dut):
    """Timer does NOT fire during normal HDR mode entered via ENTHDR CCC."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR,
        hdr_timeout_en=True, hdr_timeout_cycles=TEST_HDR_TIMEOUT_CYCLES)

    await i3c_controller.i3c_ccc_write(
        ENTHDR0, broadcast_data=[], stop=False, pull_scl_low=True)
    await ClockCycles(tb.clk, 10)
    assert_fsm_in_hdr_mode(dut)

    # Hold bus high well past threshold — timer must NOT fire for CCC-entered HDR
    await hold_bus_high(i3c_controller, i3c_target, tb, TEST_HDR_TIMEOUT_CYCLES * 3)
    assert_fsm_in_hdr_mode(dut)

    await i3c_controller.send_hdr_exit()
    assert_fsm_idle(dut)
    await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)

    await tb.teardown()


@cocotb.test()
async def test_hdr_timeout_resets_on_line_low(dut):
    """Timer resets when either SCL or SDA goes low."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR,
        hdr_timeout_en=True, hdr_timeout_cycles=TEST_HDR_TIMEOUT_CYCLES)
    tb.te_error_monitor.expect_error(0)

    await trigger_te0_error(i3c_controller)
    await ClockCycles(tb.clk, 10)
    assert_fsm_in_hdr_mode(dut)

    # Hold for 80% of threshold (not enough)
    partial_wait = int(TEST_HDR_TIMEOUT_CYCLES * 0.8)
    await hold_bus_high(i3c_controller, i3c_target, tb, partial_wait)
    assert_fsm_in_hdr_mode(dut)

    # Briefly pull SCL low to reset the timer
    i3c_controller.scl = 0
    await ClockCycles(tb.clk, 5)
    i3c_controller.scl = 1
    await ClockCycles(tb.clk, 5)

    # Another 80% — cumulative would exceed threshold, but timer was reset
    await hold_bus_high(i3c_controller, i3c_target, tb, partial_wait)
    assert_fsm_in_hdr_mode(dut)

    # Full threshold from the reset point
    await hold_bus_high(i3c_controller, i3c_target, tb, TEST_HDR_TIMEOUT_CYCLES + 50)
    assert_fsm_idle(dut)

    await i3c_controller.send_stop()
    i3c_controller.give_bus_control()
    await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)
    tb.te_error_monitor.check()

    await tb.teardown()


@cocotb.test()
async def test_hdr_timeout_disabled_by_default(dut):
    """Timer does not fire when enable bit is 0 (default)."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR,
        hdr_timeout_cycles=TEST_HDR_TIMEOUT_CYCLES)
    tb.te_error_monitor.expect_error(0)

    await trigger_te0_error(i3c_controller)
    await ClockCycles(tb.clk, 10)
    assert_fsm_in_hdr_mode(dut)

    await hold_bus_high(i3c_controller, i3c_target, tb, TEST_HDR_TIMEOUT_CYCLES * 3)
    assert_fsm_in_hdr_mode(dut)

    await i3c_controller.send_hdr_exit()
    assert_fsm_idle(dut)
    await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)
    tb.te_error_monitor.check()

    await tb.teardown()


@cocotb.test()
async def test_hdr_timeout_configurable_threshold(dut):
    """Timer fires at configured threshold, not hardcoded 60us."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    SHORT_THRESHOLD = 100
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR,
        hdr_timeout_en=True, hdr_timeout_cycles=SHORT_THRESHOLD)
    tb.te_error_monitor.expect_error(0)

    await trigger_te0_error(i3c_controller)
    await ClockCycles(tb.clk, 10)
    assert_fsm_in_hdr_mode(dut)

    await hold_bus_high(i3c_controller, i3c_target, tb, SHORT_THRESHOLD + 50)
    assert_fsm_idle(dut)

    await i3c_controller.send_stop()
    i3c_controller.give_bus_control()
    await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)
    tb.te_error_monitor.check()

    await tb.teardown()


@cocotb.test()
async def test_hdr_exit_pattern_works_alongside_timer(dut):
    """Normal HDR Exit Pattern still works when timer is enabled."""
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    LARGE_THRESHOLD = 100000
    i3c_controller, i3c_target, tb = await test_setup(
        dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR,
        hdr_timeout_en=True, hdr_timeout_cycles=LARGE_THRESHOLD)
    tb.te_error_monitor.expect_error(0)

    await trigger_te0_error(i3c_controller)
    await ClockCycles(tb.clk, 10)
    assert_fsm_in_hdr_mode(dut)

    # Exit via pattern well before timer would fire
    await i3c_controller.send_hdr_exit()
    assert_fsm_idle(dut)
    await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)
    tb.te_error_monitor.check()

    await tb.teardown()


@cocotb.test()
async def test_cycle_all_hdr_modes(dut):
    (STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR) = random.sample(VALID_I3C_ADDRESSES, 4)
    i3c_controller, _, tb = await test_setup(dut, STATIC_ADDR, VIRT_STATIC_ADDR, DYNAMIC_ADDR, VIRT_DYNAMIC_ADDR, attach_target=False)

    for enthdrx in range(ENTHDR0, ENTHDR0 + 8):
        await i3c_controller.i3c_ccc_write(enthdrx, broadcast_data=[], stop=False, pull_scl_low=True)
        assert_fsm_in_hdr_mode(dut)

        await i3c_controller.send_hdr_exit()
        assert_fsm_idle(dut)

        await verify_target_responsive(i3c_controller, DYNAMIC_ADDR)

    await tb.teardown()
